import flet as ft
from flet import *
from flet_route import Params, Basket
import json
import pyrebase
import firebase_admin
from firebase_admin import credentials
from pymongo import MongoClient

json_data = open('cred.json').read()
config = json.loads(json_data)
firebase = pyrebase.initialize_app(config)
storage = firebase.storage()
if not firebase_admin._apps:
    cred = credentials.Certificate("obconnect.json")
    firebase_admin.initialize_app(cred)

def Signin(page: ft.Page, params: Params, basket: Basket):
    page.title = "Sign in"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER

    # Email input field with icon
    txt_id = ft.TextField(
        hint_text='Enter Unique Id',
        icon=ft.icons.STAR,
    )

    # Password input field with icon
    txt_password = ft.TextField(
        hint_text='Enter password',
        password=True,
        icon=ft.icons.LOCK,

    )

    def btnClick(*args):
        print('Button working')
        id = txt_id.value.strip()
        cluster = MongoClient('mongodb+srv://deepakdashcode:!!Deepak!!@cluster0.y1ilve3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
        db = cluster['evaluate']
        collection = db['userdata']
        post = collection.find_one({'_id': id})
        if post:
            email = post['email']
            print('Email GOT IS ', email)
            password = txt_password.value.strip()
            try:
                auth = firebase.auth()
                login = auth.sign_in_with_email_and_password(email, password)
                print('Successfully Login')
            except Exception as e:
                print(f'{str(e)}')
        else:
            print('Not registered')
        

    # Sign up button
    btn_signin = ft.ElevatedButton(
        text="Sign in",
        on_click=btnClick,

    )
    btn_signUp = ft.ElevatedButton(
        text="Not a User ? Sign Up",
        on_click=lambda _:page.go('/SignUp/DK'),

    )
    # Arrange the components vertically
    return View(
        "/",
        controls=[
            ft.Column(
                [
                    txt_id,
                    txt_password,
                    btn_signin,
                    btn_signUp
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=CrossAxisAlignment.CENTER,
                spacing=20,
            )
        ]
    )




