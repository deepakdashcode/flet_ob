import firebase_admin
import flet as ft
import pyrebase
from flet import *
from flet_route import Params, Basket
import pymongo
import json

from gcloud import exceptions
from pymongo import MongoClient
import requests
from firebase_admin import firestore, credentials

json_data = open('cred.json').read()
config = json.loads(json_data)
firebase = pyrebase.initialize_app(config)
storage = firebase.storage()
if not firebase_admin._apps:
    cred = credentials.Certificate("obconnect.json")
    firebase_admin.initialize_app(cred)



def sign_up_with_email_and_password_try(email, password, username=None, registration_number=None):
    auth = firebase.auth()
    try:
        user = auth.create_user_with_email_and_password(email, password)
        print('success')
        print('**',password,'**',sep='')
        cluster = MongoClient('mongodb+srv://deepakdashcode:!!Deepak!!@cluster0.y1ilve3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
        db = cluster['evaluate']
        collection = db['userdata']
        post = {'_id': registration_number, 'email': email, 'username': username}
        collection.insert_one(post)
        return 'success'
    except Exception as e:
        return f'Error Occurred {str(e)}'




def SignUp(page: ft.Page, params: Params, basket: Basket):
    page.title = "Signup Form"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER

    # User ID input field with icon
    txt_user_id = ft.TextField(
        icon=ft.icons.STAR,
        hint_text='Enter unique id'
    )

    # Email input field with icon
    txt_email = ft.TextField(
        hint_text='Enter Email',
        icon=ft.icons.EMAIL,
    )

    # Password input field with icon
    txt_password = ft.TextField(
        hint_text='Enter password',
        password=True,
        icon=ft.icons.LOCK,

    )

    txt_username = ft.TextField(
        hint_text='Enter Username',
        icon=ft.icons.PERSON,

    )
    txt_result = ft.Text(
        value='',
        selectable=True
    )

    def btnClick(*args):
        sign_up_with_email_and_password_try(
            txt_email.value.strip(),
            txt_password.value.strip(),
            txt_username.value.strip(),
            txt_user_id.value.strip()
        )

    # Sign up button
    btn_signup = ft.ElevatedButton(
        text="Sign Up",
        on_click=btnClick,

    )
    btn_signin = ft.ElevatedButton(
        text="Already a user ? Sign In",
        on_click=lambda _: page.go('/'),

    )

    btn_quiz = ft.ElevatedButton(
        text="quiz",
        on_click=lambda _: page.go('/quiz/dk'),

    )
    # Arrange the components vertically
    return View(
        "/SignUp",
        controls=[
            ft.Column(
                [
                    txt_user_id,
                    txt_username,
                    txt_email,
                    txt_password,
                    btn_signup,
                    btn_signin,
                    btn_quiz,
                    txt_result
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=CrossAxisAlignment.CENTER,
                spacing=20,
            )
        ]
    )
