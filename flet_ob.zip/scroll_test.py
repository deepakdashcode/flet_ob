from flet import *

def main(page: Page):
    bd = Column(
        scroll='always'
    )

    for i in range(30):
        bd.controls.append(
            Text(f'Data {i + 1}')
        )
    
    page.title = "Sign in"
    page.scroll = ScrollMode.ALWAYS
    page.theme = Theme(
        scrollbar_theme=ScrollbarTheme(
            track_color={
                MaterialState.HOVERED: 'green',
                MaterialState.DEFAULT: 'blue',
            },
            track_visibility=True,
            track_border_color='red',
            thumb_visibility=True,
            thumb_color={
                MaterialState.HOVERED: colors.AMBER_100,
                MaterialState.DEFAULT: colors.YELLOW_600,
            },
            thickness=5,
            radius=3
        )
    )
    page.vertical_alignment = MainAxisAlignment.CENTER
    page.horizontal_alignment = CrossAxisAlignment.CENTER
    page.add(bd)

app(target=main, view=AppView.WEB_BROWSER)