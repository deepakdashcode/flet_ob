import flet as ft
from flet import *
import json
import pyrebase
import firebase_admin
from firebase_admin import credentials
from pymongo import MongoClient
import random as r
import pandas as pd

current_id = ''
def generate_id():
    ls = [str(r.randint(1, 9)) for i in range(16)]
    id = ''.join(ls)
    return id

def main(page: ft.Page):
    page.title = "Sign in"
    page.scroll = ScrollMode.ALWAYS
    page.theme = Theme(
        scrollbar_theme=ScrollbarTheme(
            track_color={
                MaterialState.HOVERED: 'green',
                MaterialState.DEFAULT: 'blue',
            },
            track_visibility=True,
            track_border_color='red',
            thumb_visibility=True,
            thumb_color={
                MaterialState.HOVERED: colors.AMBER_100,
                MaterialState.DEFAULT: colors.YELLOW_600,
            },
            thickness=5,
            radius=3
        )
    )
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    
    # Configure firebase
    json_data = open('cred.json').read()
    config = json.loads(json_data)
    firebase = pyrebase.initialize_app(config)
    storage = firebase.storage()
    if not firebase_admin._apps:
        cred = credentials.Certificate("obconnect.json")
        firebase_admin.initialize_app(cred)
    
    txt_id = ft.TextField(
        hint_text='Enter Unique Id',
        icon=ft.icons.STAR,
    )

    # Password input field with icon
    txt_password = ft.TextField(
        hint_text='Enter password',
        password=True,
        icon=ft.icons.LOCK,

    )
    txt_result_signin = Text(
        value='',
        selectable=True
    )

    def btnClick(*args):
        
        print('Button working')
        user_id = txt_id.value.strip()
        cluster = MongoClient('mongodb+srv://deepakdashcode:!!Deepak!!@cluster0.y1ilve3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
        db = cluster['evaluate']
        collection = db['userdata']
        post = collection.find_one({'_id': user_id})
        if post:
            email = post['email']
            print('Email GOT IS ', email)
            password = txt_password.value.strip()
            try:
                auth = firebase.auth()
                login = auth.sign_in_with_email_and_password(email, password)
                txt_result_signin.value = 'Successfully Login'
                page.update()
                print(txt_result_signin.value)
                global current_id
                current_id = user_id
                page.go('/teacherlogin')
            except Exception as e:
                txt_result_signin.value = f'{str(e)}'
                page.update()
                print(txt_result_signin.value)
        else:
            txt_result_signin.value = 'Not registered'
            page.update()
            print(txt_result_signin.value)
        

    # Sign up button
    btn_signin = ft.ElevatedButton(
        text="Sign in",
        on_click=btnClick,

    )
    btn_signUp = ft.ElevatedButton(
        text="Not a User ? Sign Up",
        on_click=lambda _:page.go('/SignUp'),

    )
    
    def route_change(route):
        page.views.clear()
        page.views.append(
            ft.View(
                "/",
                controls=[
                    ft.Column(
                    [
                    txt_id,
                    txt_password,
                    btn_signin,
                    btn_signUp,
                    txt_result_signin
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=CrossAxisAlignment.CENTER,
                spacing=20,
            ),
                ft.AppBar(title=ft.Text("Sign In"), bgcolor=ft.colors.SURFACE_VARIANT),
                ],
            )
        )
        if page.route == "/quiz":
            col = Column(
                scroll=ScrollMode.ALWAYS
            )
            print('Entered quiz')
            page.title = "Teacher Dashboard"
            txt_id_quiz = Text(
                selectable=True
            )
            all_elements = []
            all_questions = [
                Row(
                    alignment=MainAxisAlignment.START,
                    vertical_alignment=CrossAxisAlignment.CENTER,
                        controls=[
                            TextField(
                                hint_text='Enter The Question',
                                icon=ft.icons.BOOK,
                                width=page.width * 0.85
                            ),
                            TextField(
                                hint_text='Marks',
                                width=page.width * 0.08
                            )
                        ]
                    )
            ]
            
            def btnAddQues(*args):
                print('Add ques called')
                print(all_questions)
                print('all elements = ', all_elements)
                all_elements.insert(-2, Row(
                    controls=[
                        TextField(
                            hint_text='Enter The Question',
                            icon=ft.icons.BOOK,
                            width=page.width * 0.85
                        ),
                        TextField(
                            hint_text='Marks',
                            keyboard_type=KeyboardType.NUMBER,
                            width=page.width * 0.08
                        )
                    ]
                ))
                page.update()
            txt_quiz_name = TextField(
                            hint_text='Enter The Name of Quiz',
                            icon=ft.icons.BOOK,
                            width=page.width * 0.85,
                            text_align=TextAlign.CENTER
                        )
            all_elements = [
                txt_quiz_name,
                ElevatedButton(
                    text="Add Question",
                    on_click=btnAddQues
                )
            ]
            all_elements += all_questions

            def btnCreateQuiz(*args):
                question_mark_list = []
                for element in all_elements:
                    if type(element) == Row:
                        question = element.controls[0].value
                        marks = element.controls[1].value
                        print('Question = ', question)
                        print('Marks = ', marks)
                        temp = [question, marks]
                        question_mark_list.append(temp)

                df = pd.DataFrame(question_mark_list, columns=['Question', 'Marks'])

                

                quiz_id = generate_id()

                txt_id_quiz.value = f'Your Test id is {quiz_id}'
                df['test_id'] = str(quiz_id)
                all_data = df.to_dict(orient='records')
                cluster = MongoClient('mongodb+srv://deepakdashcode:!!Deepak!!@cluster0.y1ilve3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
                db = cluster['evaluate']
                collection = db['questions']
                collection.insert_many(all_data)
                txt_id_quiz.value = f'Quiz id is {quiz_id}'
                collection = db['createdquiz']
                
                collection.insert_one({'_id': quiz_id, 'name': txt_quiz_name.value.strip(), 'userid': f'{current_id}'})
                page.update()
                print(f'Quiz id is {quiz_id}')
                # upload_csv(f'{id}.csv')

            all_elements.append(
                    ElevatedButton(
                        text='Create Quiz',
                        on_click=btnCreateQuiz
                    )
                )
            all_elements.append(
                    txt_id_quiz
                )
            
            
            page.views.append(
                    View(
                        '/quiz',
                        controls=[
                        
                                Column(
                                    expand=True,
                                    controls=all_elements,
                                    alignment=ft.MainAxisAlignment.CENTER,
                                    horizontal_alignment=CrossAxisAlignment.CENTER,
                                    spacing=20,
                                    scroll=ScrollMode.ALWAYS
                            ),
                            AppBar(title=ft.Text("Create Quiz"), bgcolor=ft.colors.SURFACE_VARIANT, center_title=True)
                        ], 
                    )
                )
            page.update()
        
        if page.route == "/evaluatequiz":
            def get_id_eval():
                global current_id
                return current_id
            user_id_eval = get_id_eval()
            cluster = MongoClient('mongodb+srv://deepakdashcode:!!Deepak!!@cluster0.y1ilve3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
            db = cluster['evaluate']
            collection = db['createdquiz']
            get_quizes = list(collection.find({'userid': user_id_eval}))
            print(get_quizes)
            all_elements_evaluate = []
            for quiz in get_quizes:
                txt_curr_name = Text(quiz['name'], selectable=True)
                txt_curr_id = Text(quiz['_id'], selectable=True)
                all_elements_evaluate.append(
                    Row(
                        controls=[
                            txt_curr_name,
                            txt_curr_id
                        ]
                    )
                )

            txt_id_evaluate = TextField(
                    hint_text='Enter the id of the test to evaluate it'
                )
            all_elements_evaluate.append(txt_id_evaluate)
            def evaluate_test_function(*args):
                print('Will Evaluate txt_id : ', txt_id_evaluate.value)
            btn_evaluate_test = ElevatedButton(
                    text='Evaluate',
                    on_click=evaluate_test_function
                )
            all_elements_evaluate.append(btn_evaluate_test)
            
            page.views.append(
                ft.View(
                    "/attemptquiz",
                    [
                        ft.Column(
                            controls=all_elements_evaluate,
                            alignment=ft.MainAxisAlignment.CENTER,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            spacing=20,
                        ),
                        ft.AppBar(title=ft.Text("Dashboard"), bgcolor=ft.colors.SURFACE_VARIANT),
                    ],
                )
            )
            
            
            pass
        if page.route == "/attemptquiz":
            page.title = "Attempt Quiz"
            txt_id_quiz_attempt = TextField(
                hint_text='Enter the id of the test'
            )
            
            def btn_attempt(*args):
                global current_id
                uid = current_id
                test_id = txt_id_quiz_attempt.value.strip()
                cluster = MongoClient('mongodb+srv://deepakdashcode:!!Deepak!!@cluster0.y1ilve3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
                db = cluster['evaluate']
                collection = db['questions']
                data = collection.find({'test_id': test_id})
                ls = list(data)
                print(ls)
                df = pd.DataFrame(ls)
                df = df.drop('_id', axis=1)
                df = df.drop('test_id', axis=1)
                dict_data = df.to_dict(orient='records')
                print(df)

                ll = [[d[key] for key in d] for d in dict_data] # list of list of question and marks
                all_elements_attempt = []
                for ques in ll:
                    all_elements_attempt.append(
                        Text(f'{ques[0]} [{ques[1]}]')
                    )
                    all_elements_attempt.append(
                        TextField(
                            hint_text='Enter your answer here',
                            multiline=True
                        )
                    )
                


                def submit_answers(*args):
                    cluster = MongoClient('mongodb+srv://deepakdashcode:!!Deepak!!@cluster0.y1ilve3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
                    db = cluster['evaluate']
                    collection = db['answers']
                    i = 0
                    post = {'test_id': test_id, 'user_id': current_id}
                    while i < len(all_elements_attempt):
                        if type(all_elements_attempt[i]) == Text:
                            post[all_elements_attempt[i].value] = all_elements_attempt[i + 1].value
                        i += 2
                    
                    print(post)
                    collection.insert_one(post)


                btn_submit_ans = ElevatedButton(
                    text='Submit',
                    on_click=submit_answers
                )
                all_elements_attempt.append(btn_submit_ans)
                
                page.views.clear()
                page.views.append(
                ft.View(
                    "/attemptquiz",
                    [
                        ft.Column(
                            controls=all_elements_attempt,
                            alignment=ft.MainAxisAlignment.CENTER,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            spacing=20,
                        ),
                        ft.AppBar(title=ft.Text("Dashboard"), bgcolor=ft.colors.SURFACE_VARIANT),
                    ],
                )
                )
                page.update()


            
            btn_attempt_quiz = ElevatedButton(
                text='Attempt Test',
                on_click=btn_attempt
            )
            
            page.views.append(
                ft.View(
                    "/attemptquiz",
                    [
                        ft.Column(
                            controls=[
                                txt_id_quiz_attempt,
                                btn_attempt_quiz
                            ],
                            alignment=ft.MainAxisAlignment.CENTER,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            spacing=20,
                        ),
                        ft.AppBar(title=ft.Text("Dashboard"), bgcolor=ft.colors.SURFACE_VARIANT),
                    ],
                )
            )
            pass
        if page.route == "/teacherlogin":
            # MongoDB
            cluster = MongoClient('mongodb+srv://deepakdashcode:!!Deepak!!@cluster0.y1ilve3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
            db = cluster['evaluate']
            collection = db['userdata']

            # Initialise Page
            page.title = "Dashboard"
            global current_id
            uid = current_id
            try:
                post = collection.find_one({'_id': uid})
                username = post['username']
                email = post['email']
                txt_Dashboard = Text(
                    value=f'Username: {username}\nEmail: {email}\nId: {uid}',
                    selectable=True,
                    size=20,
                    text_align=TextAlign.CENTER
                )
            except:
                print('Some error occurred')

            def create_quiz(*args):
                page.go('/quiz')
            btn_create_quiz = ElevatedButton(
                text='Create Quiz',
                on_click=create_quiz
            )
            btn_go_to_attempt_quiz = ElevatedButton(
                text='Attempt Quiz',
                on_click=lambda _:page.go('/attemptquiz')
            )
            btn_go_to_evaluate_quiz = ElevatedButton(
                text='Evaluate Quiz',
                on_click=lambda _:page.go('/evaluatequiz')
            )
            page.horizontal_alignment = MainAxisAlignment.CENTER
            page.vertical_alignment = MainAxisAlignment.CENTER
            page.views.append(
                ft.View(
                    "/teacherlogin",
                    [
                        ft.Column(
                            controls=[
                                txt_Dashboard,
                                btn_create_quiz,
                                btn_go_to_attempt_quiz,
                                btn_go_to_evaluate_quiz
                                
                            ],
                            spacing=20,
                            adaptive=True,
                            horizontal_alignment=CrossAxisAlignment.STRETCH
                        ),
                        ft.AppBar(title=ft.Text("Dashboard"), bgcolor=ft.colors.SURFACE_VARIANT),
                    ],
                )
            )





        if page.route == "/SignUp":
            page.title = "Signup Form"
            page.vertical_alignment = ft.MainAxisAlignment.CENTER
            txt_user_idSUP = ft.TextField(
                icon=ft.icons.STAR,
                hint_text='Enter unique id'
            )       

            # Email input field with icon
            txt_emailSUP = ft.TextField(
                hint_text='Enter Email',
                icon=ft.icons.EMAIL,
            )

            # Password input field with icon
            txt_passwordSUP = ft.TextField(
                hint_text='Enter password',
                password=True,
                icon=ft.icons.LOCK,

            )

            txt_usernameSUP = ft.TextField(
                hint_text='Enter Username',
                icon=ft.icons.PERSON,

            )
            txt_resultSUP = ft.Text(
                value='',
                selectable=True
            )
            def sign_up_with_email_and_password_try(email, password, username=None, registration_number=None):
                auth = firebase.auth()
                try:
                    user = auth.create_user_with_email_and_password(email, password)
                    print('Created user successfully')
                    print('**',password,'**',sep='')
                    cluster = MongoClient('mongodb+srv://deepakdashcode:!!Deepak!!@cluster0.y1ilve3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
                    db = cluster['evaluate']
                    collection = db['userdata']
                    post = {'_id': registration_number, 'email': email, 'username': username}
                    collection.insert_one(post)
                    txt_resultSUP.value = 'Registered Successfully'
                    page.update()
                    global current_id
                    current_id = registration_number
                    page.go('/teacherlogin')
                except Exception as e:
                    txt_resultSUP.value = f'Error Occurred {str(e)}'
                    page.update()
            def btnClickSignup(*args):
                sign_up_with_email_and_password_try(
                    txt_emailSUP.value.strip(),
                    txt_passwordSUP.value.strip(),
                    txt_usernameSUP.value.strip(),
                    txt_user_idSUP.value.strip()
                )
            btn_signupSUP = ft.ElevatedButton(
                text="Sign Up",
                on_click=btnClickSignup,
            )
            btn_signinSUP = ft.ElevatedButton(
                text="Already a user ? Sign In",
                on_click=lambda _: page.go('/'),
            )

            page.views.append(
                ft.View(
                    "/SignUp",
                    [
                        ft.Column(
                [
                    txt_user_idSUP,
                    txt_usernameSUP,
                    txt_emailSUP,
                    txt_passwordSUP,
                    btn_signupSUP,
                    btn_signinSUP,
                    txt_resultSUP
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=CrossAxisAlignment.CENTER,
                spacing=20,
            ),
                        ft.AppBar(title=ft.Text("Store"), bgcolor=ft.colors.SURFACE_VARIANT),
                    ],
                )
            )
        page.update()

    def view_pop(view):
        page.views.pop()
        top_view = page.views[-1]
        page.go(top_view.route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop
    page.go(page.route)


ft.app(target=main, view=ft.AppView.WEB_BROWSER)