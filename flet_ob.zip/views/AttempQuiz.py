import flet as ft
from flet import *
from flet_route import Params, Basket
import pandas as pd


def process_csv(csv_file):
    # Read CSV file
    # print(csv_file.read().decode('utf-8'))
    data = open(csv_file).read().strip().split('\n')
    print('data = ', data)
    # Initialize list to store questions and marks
    questions_and_marks = []
    # Split each line into question and marks pairs
    for line in data:
        # Ignore empty lines
        if line.strip():
            # Split each line by the backtick (`) separator
            line_parts = line.split('`')
            # Append the pair as a single sublist
            questions_and_marks.append(line_parts)
    print('Question and answers = ', questions_and_marks)
    return questions_and_marks

process_csv('1433736173194518.csv')


def AttemptQuiz(page: ft.Page, params: Params, basket: Basket):
    page.title = "Attempt Quiz"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    txt_id = TextField(
                    hint_text='Enter The ID of quiz',
                    icon=ft.icons.BOOK,
                    width=page.width * 0.85
                ),

    # Email input field with icon
    all_elements = []


    all_questions = [
        Row(
            alignment=MainAxisAlignment.START,
            vertical_alignment=CrossAxisAlignment.CENTER,
            controls=[
                TextField(
                    hint_text='Enter The Question',
                    icon=ft.icons.BOOK,
                    width=page.width * 0.85
                ),
                TextField(
                    hint_text='Marks',
                    width=page.width * 0.08
                )
            ]
        )
    ]

    def btnAddQues(*args):
        print('Add ques called')
        print(all_questions)
        print('all elements = ', all_elements)
        all_elements.insert(-2, Row(
            controls=[
                TextField(
                    hint_text='Enter The Question',
                    icon=ft.icons.BOOK,
                    width=page.width * 0.85
                ),
                TextField(
                    hint_text='Marks',
                    keyboard_type=KeyboardType.NUMBER,
                    width=page.width * 0.08
                )
            ]
        ))

        page.update()
        # page.go('/quiz/dk')

    all_elements = [
        ElevatedButton(
            text="Add Question",
            on_click=btnAddQues
        )
    ]
    all_elements += all_questions

    def btnCreateQuiz(*args):
        question_mark_list = []
        for element in all_elements:
            if type(element) == Row:
                question = element.controls[0].value
                marks = element.controls[1].value
                print('Question = ', question)
                print('Marks = ', marks)
                temp = [question, marks]
                question_mark_list.append(temp)

        df = pd.DataFrame(question_mark_list, columns=['Question', 'Marks'])

        custom_delimiter = '`'

        id = generate_id()
        txt_id.value = f'Your Test id is {id}'
        df.to_csv(f"{id}.csv", index=False, sep=custom_delimiter)

        page.update()
        pass

    all_elements.append(
        ElevatedButton(
            text='Create Quiz',
            on_click=btnCreateQuiz
        )
    )
    all_elements.append(
        txt_id
    )
    # Arrange the components vertically
    return View(
        "/",
        controls=[
            ListView(
                controls=
                [Column(
                    controls=all_elements,
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=CrossAxisAlignment.CENTER,
                    spacing=20,
                    scroll=ScrollMode.ALWAYS
                )],
                auto_scroll=True,

            )

        ]
    )
