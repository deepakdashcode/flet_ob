from flet import *

r = Row(
    controls=[Text('Deepak'),
    ElevatedButton(text='hii')
    ]
)
print(type(r.controls[1]))