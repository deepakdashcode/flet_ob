import flet as ft

def main(page: ft.Page):
    page.title = "My App"
    page.scroll = ft.ScrollMode.AUTO

    def route_change(route):
        page.views.clear()
        page.views.append(
            ft.View(
                "/",
                [
                    ft.Container(
                        expand=True,
                        content=ft.Column(
                            [
                                ft.Text("Hello, world!"),
                                ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ft.Text("Hello, world!"),
                            ],
                            spacing=20,
                        ),
                    )
                ],
            )
        )
        page.update()

    page.on_route_change = route_change
    page.go("/")

ft.app(target=main)