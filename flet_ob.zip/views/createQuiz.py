import flet as ft
from flet import *
from flet_route import Params, Basket
import pandas as pd
import random as r
import json
import pyrebase

json_data = open('cred.json').read()
config = json.loads(json_data)
firebase = pyrebase.initialize_app(config)


def generate_id():
    ls = [str(r.randint(1, 9)) for i in range(16)]
    id = ''.join(ls)
    return id


def upload_csv(filename: str):
    cloudpath = f'csv/{filename}'
    firebase.storage().child(cloudpath).put(filename)


def Quiz(page: ft.Page, params: Params, basket: Basket):
    page.title = "Create Quiz"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    txt_id = Text(
        selectable=True
    )



    # Email input field with icon
    all_elements = []
    all_questions = [
        Row(
            alignment=MainAxisAlignment.START,
            vertical_alignment=CrossAxisAlignment.CENTER,
            controls=[
                TextField(
                    hint_text='Enter The Question',
                    icon=ft.icons.BOOK,
                    width=page.width * 0.85
                ),
                TextField(
                    hint_text='Marks',
                    width=page.width * 0.08
                )
            ]
        )
    ]

    def btnAddQues(*args):
        print('Add ques called')
        print(all_questions)
        print('all elements = ', all_elements)
        all_elements.insert(-2, Row(
            controls=[
                TextField(
                    hint_text='Enter The Question',
                    icon=ft.icons.BOOK,
                    width=page.width * 0.85
                ),
                TextField(
                    hint_text='Marks',
                    keyboard_type=KeyboardType.NUMBER,
                    width=page.width * 0.08
                )
            ]
        ))

        page.update()
        # page.go('/quiz/dk')

    all_elements = [
        ElevatedButton(
            text="Add Question",
            on_click=btnAddQues
        )
    ]
    all_elements += all_questions

    def btnCreateQuiz(*args):
        question_mark_list = []
        for element in all_elements:
            if type(element) == Row:
                question = element.controls[0].value
                marks = element.controls[1].value
                print('Question = ', question)
                print('Marks = ', marks)
                temp = [question, marks]
                question_mark_list.append(temp)

        df = pd.DataFrame(question_mark_list, columns=['Question', 'Marks'])

        custom_delimiter = '`'

        id = generate_id()

        txt_id.value = f'Your Test id is {id}'
        df.to_csv(f"{id}.csv", index=False, sep=custom_delimiter)
        upload_csv(f'{id}.csv')

        page.update()
        pass

    all_elements.append(
        ElevatedButton(
            text='Create Quiz',
            on_click=btnCreateQuiz
        )
    )
    all_elements.append(
        txt_id
    )
    # Arrange the components vertically
    return View(
        "/",
        controls=[
            ListView(
                controls=
                [Column(
                    controls=all_elements,
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=CrossAxisAlignment.CENTER,
                    spacing=20,
                    scroll=ScrollMode.ALWAYS
                )],
                auto_scroll=True,

            )

        ]
    )
