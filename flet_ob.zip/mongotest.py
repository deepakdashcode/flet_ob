from pymongo import MongoClient
import pandas as pd
cluster = MongoClient('mongodb+srv://deepakdashcode:!!Deepak!!@cluster0.y1ilve3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
db = cluster['evaluate']
collection = db['questions']
data = collection.find({'test_id': '9394568857837889'})
ls = list(data)
print(ls)
df = pd.DataFrame(ls)
df = df.drop('_id', axis=1)
df = df.drop('test_id', axis=1)
dict_data = df.to_dict(orient='records')
print(df)


ll = [[d[key] for key in d] for d in dict_data]
print(ll)
